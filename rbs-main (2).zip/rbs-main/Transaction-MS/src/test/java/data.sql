INSERT INTO TRANSACTION(id, source_Account_Id,source_Owner_Name,target_Account_Id,target_Owner_Name,amount,date_Of_Transaction,type_Of_Transaction)
VALUES (1, 1,'Ivan', 2, 'Ivan', 250.00, '2021-04-28 12:00', 'transfer');
INSERT INTO TRANSACTION(id, source_Account_Id,source_Owner_Name,target_Account_Id,target_Owner_Name,amount,date_Of_Transaction,type_Of_Transaction)
VALUES (1, 1,'Ivan', 2, 'Ivan', 250.00, '2021-04-2 12:00', 'transfer');

