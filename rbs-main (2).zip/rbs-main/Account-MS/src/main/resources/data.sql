
insert into ACCOUNT(account_Id,customer_Id,balance,account_Type,owner_Name) values(52535, 'CUST101', 1000, 'Savings', 'Vijay');
insert into ACCOUNT(account_Id,customer_Id,balance,account_Type,owner_Name) values(52536, 'CUST101', 2000, 'Current', 'Vijay');
insert into ACCOUNT(account_Id,customer_Id,balance,account_Type,owner_Name) values(52537, 'CUST101', 3000, 'Savings', 'Vijay');

insert into ACCOUNT(account_Id,customer_Id,balance,account_Type,owner_Name) values(52538, 'CUST102', 4000, 'Savings', 'Nada');
insert into ACCOUNT(account_Id,customer_Id,balance,account_Type,owner_Name) values(52539, 'CUST102', 5000, 'Current', 'Nada');

insert into ACCOUNT(account_Id,customer_Id,balance,account_Type,owner_Name) values(52540, 'CUST103', 6000, 'Savings', 'Priya');