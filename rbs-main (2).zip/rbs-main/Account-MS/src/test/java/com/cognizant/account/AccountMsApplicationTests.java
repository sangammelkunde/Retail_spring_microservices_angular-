package com.cognizant.account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/*
 * The default test class of the account microservice.
 */

@SpringBootTest
class AccountMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
