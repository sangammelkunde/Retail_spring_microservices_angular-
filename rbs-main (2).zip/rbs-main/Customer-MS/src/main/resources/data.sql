
insert into CUSTOMER(userid, username, password, date_of_birth, pan_no, address) values('CUST101', 'Vijay', 'pass', '1995-05-05', 'DZQPB8574K', 'Chennai');

insert into CUSTOMER(userid, username, password, date_of_birth, pan_no, address) values('EMP101', 'Yuvaraj', 'pass', '1991-01-01', 'WSAQW8521L', 'Bangalore');

insert into CUSTOMER(userid, username, password, date_of_birth, pan_no, address) values('CUST102', 'Nada', 'pass', '1993-03-03', 'WSTGW8521L', 'Chennai');

insert into CUSTOMER(userid, username, password, date_of_birth, pan_no, address) values('CUST103', 'Priya', 'pass', '1994-04-04', 'RDTGW8521L', 'Bangalore');