package com.cognizant.RetailBanking.Customers.Exception;

public class ServiceFailException extends Exception{
	public ServiceFailException(String message)
	{
		super(message);
	}

}
