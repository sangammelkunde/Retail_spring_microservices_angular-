package com.cognizant.RetailBanking.Customers.Exception;
public class LoginFailedException extends RuntimeException {

	/**
	 * 		Login Failed Exception
	 */
	private static final long serialVersionUID = 1L;

}