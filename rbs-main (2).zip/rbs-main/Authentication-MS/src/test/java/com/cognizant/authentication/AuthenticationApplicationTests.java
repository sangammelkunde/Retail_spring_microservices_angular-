package com.cognizant.authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * AuthenticationApplication Test Cases
 * @author Pod-4
 *
 */
@SpringBootTest
class AuthenticationApplicationTests {
	/**
	 * Context Loader Test case
	 */
	@Test
	void contextLoads() {
	}

}
