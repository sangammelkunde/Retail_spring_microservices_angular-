export interface TransactionInput{
    sourceAccount:number,
    targetAccount:number,
    amount:number,
    typeOfTrasaction:string,

}