export interface Account{
    accountId:number,
    customerId:string,
    balance:number,
    accountType:string,
    ownerName:string,
}