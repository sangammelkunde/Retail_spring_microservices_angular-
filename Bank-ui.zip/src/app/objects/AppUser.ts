export interface AppUser{
    userid:string,
    username:string,
    password:string,
    authToken:string,
    role:string,
}