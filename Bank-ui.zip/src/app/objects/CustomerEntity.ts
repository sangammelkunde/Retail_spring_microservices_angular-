export interface CustomerEntity{
    userid:string,
    username:string,
    password:string,
    dateOfBirth:string,
    pan_no:string,
    address:string
}