export interface AuthenticationResponse{
    userid:string,
    name:string,
    isValid:boolean,
}