export interface AccountInfo{
    accountId:number,
    balance:number,
}