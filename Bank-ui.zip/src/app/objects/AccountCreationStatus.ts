export interface AccountCreationStatus{
    accountId:number,
    message:string,
}