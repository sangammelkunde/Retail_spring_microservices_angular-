export const MS_URLS={
    account:"http://localhost:9997/account-ms",
    auth:"http://localhost:9995/auth-ms",
    transaction:"http://localhost:9998/transaction-ms",
    customer:"http://localhost:9999/customer-ms",
}