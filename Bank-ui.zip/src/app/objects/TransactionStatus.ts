export interface TransactionStatus{
    message:string,
    initialBalance:number,
    finalBalance:number,
}