import { Component, OnInit } from '@angular/core';
//to show error status
@Component({
  selector: 'app-errorstatus',
  templateUrl: './errorstatus.component.html',
  styleUrls: ['./errorstatus.component.css']
})
export class ErrorstatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
